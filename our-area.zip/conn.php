<?php
// $db = mysqli_connect("localhost", "root", "", "our_area") or die(mysqli_error($db));
$db = mysqli_connect("localhost", "oursitedemo_ourarea", "wIKlJ(_!@UcQ", "oursitedemo_ourarea") or die(mysqli_error($db));
